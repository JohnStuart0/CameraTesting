package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ProfileActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_IMAGE = 2;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    private static final int MY_STORAGE_REQUEST_CODE = 101;
    private String currentPhotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    public void SetTeamIcon(View view) {
        Intent returnIntent = new Intent();

        ImageView selectedImage = (ImageView) view;

        if (selectedImage.getId() == R.id.loadedImage) {
          returnIntent.putExtra("imageUrl", currentPhotoPath);
          setResult(RESULT_OK, returnIntent);
        }
        else {
          returnIntent.putExtra("imageID", selectedImage.getId());
          setResult(RESULT_OK, returnIntent);
        }
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Intent returnIntent = new Intent();

        if (resultCode != Activity.RESULT_CANCELED && data != null) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                ImageView imageView = (ImageView) findViewById(R.id.loadedImage);
                Bitmap bp = BitmapFactory.decodeFile(currentPhotoPath);
                imageView.setImageBitmap(bp);
                returnIntent.putExtra("imageUrl", currentPhotoPath);
                setResult(33, returnIntent);
            } else if (requestCode == REQUEST_IMAGE) {
                Uri selectedImage = data.getData();
                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String picturePath = cursor.getString(columnIndex);
                cursor.close();
                ImageView imageView = (ImageView) findViewById(R.id.loadedImage);
                imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
                returnIntent.putExtra("imageUrl", picturePath);
                setResult(33, returnIntent);
            }
        }
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
      super.onRequestPermissionsResult(requestCode, permissions, grantResults);
      if (requestCode == MY_CAMERA_REQUEST_CODE || requestCode == MY_STORAGE_REQUEST_CODE) {
          if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
              Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
          } else {
              Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
          }
    }
  }

  public void loadFromPhone(View view) {
    if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_DENIED) {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                },
                MY_STORAGE_REQUEST_CODE);
    } else {
        Intent takePictureIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE);
    }
  }

  public void openCamera(View view) throws IOException {
      Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

      File photoFile;
      photoFile = createImageFile();

      Uri photoUri = Uri.fromFile(photoFile);
      cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
      startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);

  }

  public File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image; }
}
